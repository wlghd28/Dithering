#include <stdio.h>
#include <stdlib.h>
#include <windows.h>


void Void_And_Cluster();
void Blue_Noise();
void Centroidal_Voronoi_Tessellation();

int main(void)
{



	return 0;
}
void Void_And_Cluster()
{

}

void Blue_Noise()
{

}

void Centroidal_Voronoi_Tessellation()
{

}