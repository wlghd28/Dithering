# BlueNoise
A SciPy implementation of the void-and-cluster method for generation of blue noise textures with arbitrary dimension.

For more information see the corresponding blog post:
http://momentsingraphics.de/?p=127
