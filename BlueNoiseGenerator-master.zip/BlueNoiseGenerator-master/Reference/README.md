# Blue Noise Reference Images

These are generated with an executable from http://drivenbynostalgia.com/files/forcedrandomsampling/code.zip

For more information, see http://drivenbynostalgia.com/files/DA.pdf - and follow the generous author https://twitter.com/nostalgiadriven

![image](https://github.com/pixelmager/BlueNoiseGenerator/blob/master/Reference/analysis_compare.png)
