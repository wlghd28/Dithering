#ifndef CONFIG_H
#define CONFIG_H

// settings
// SSE ok for 2D textures, but too imprecise for 3D
//#define USE_SSE
//#define USE_FAST_POW_SSE
//#define USE_FAST_EXP
#define USE_FAST_MODULO
#define USE_FAST_DIV

#endif
